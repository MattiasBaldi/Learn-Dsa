// stack.c
#include <stdio.h>
#include "stack.h"

void initialize(Stack *stack) {
    stack->top = -1;
}

bool isEmpty(const Stack *stack) {
    return stack->top == -1;
}

bool isFull(const Stack *stack) {
    return stack->top == MAX_SIZE - 1;
}

void push(Stack *stack, int value) {
    if (isFull(stack)) return;
    stack->arr[++stack->top] = value;
}

int pop(Stack *stack) {
    if (isEmpty(stack)) return -1;
    return stack->arr[stack->top--];
}

int peek(const Stack *stack) {
    if (isEmpty(stack)) return -1;
    return stack->arr[stack->top];
}
